import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pag4',
  templateUrl: './pag4.component.html',
  styleUrls: ['./pag4.component.css']
})
export class Pag4Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
