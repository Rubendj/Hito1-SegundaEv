import { TestBed } from '@angular/core/testing';

import { AuditInterceptorService } from './audit-interceptor.service';

describe('AuditInterceptorService', () => {
  let service: AuditInterceptorService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(AuditInterceptorService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
