export class Check {
    id: number = 0;
    imagen: string;
    nombre: string;
    apellido: string;
}
