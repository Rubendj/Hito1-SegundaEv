import { Component, OnInit } from '@angular/core';
import { Check } from './models/check';

@Component({
  selector: 'app-pag3',
  templateUrl: './pag3.component.html',
  styleUrls: ['./pag3.component.css']
})
export class Pag3Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

  checkArray: Check[] = [
    {id: 1, imagen: "https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcTm58KipPV5JmSddCam2MnwGE7U7uAGPW5DRV5Lg-zLWvQMy5Pn", nombre: "Juanma", apellido: "Pastor"},
    {id: 2, imagen: "https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcR30eFGyyK8MOFXl77_VrDMdiduRoJgGkjfs8OX4AJbeYOaPBgh", nombre: "Chisto", apellido: "Espin"},
    {id: 3, imagen: "https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcRBTYwzaI16doxDmpNrR5u6km_1hqFjI49kX1FXXUZWdHeMTDLd", nombre: "Jaime", apellido: "Galindo"},
    {id: 4, imagen: "https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcSgzREj9u08-Hg4XF9xT2MXaCnbo7_8tnaK7K1ZYHOlwVCvY7eK", nombre: "Alberto", apellido: "Benavente"},
    {id: 5, imagen: "https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcSpz5bkRKJP5v-GU0hUUe1lWee89ny1HluixSjFx1lch_EZT0o6", nombre: "Victor", apellido: "Cuadrillero"},
    {id: 6, imagen: "https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcRn20QICEk0AkkKS8KjkhUh4ckn17KwZKTnuFcgXqLbypQA8huV", nombre: "Pedro", apellido: "Heras"}

  ];

}
