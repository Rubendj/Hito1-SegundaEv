export class Empleados {
    id: number;
    nombre: string;
    ciudad: string;
}
