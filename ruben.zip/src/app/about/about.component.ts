import { Component, OnInit } from '@angular/core';

import { Empleados } from './models/empleados';
@Component({
  selector: 'app-about',
  templateUrl: './about.component.html',
  styleUrls: ['./about.component.css']
})
export class AboutComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

  empleadoArray: Empleados[] = [
    {id: 1, nombre: "Juanma",ciudad: "Madrid"},
    {id: 2, nombre: "Chisto",ciudad: "Zaragoza"},
    {id: 3, nombre: "Jaime",ciudad: "Barcelona"}

  ];

  selectedEmpleado: Empleados = new Empleados();

  openForEdit(empleado: Empleados) {
    this.selectedEmpleado = empleado;
  }

  addOrEdit(){
    if(this.selectedEmpleado.id === 0){
      this.selectedEmpleado.id = this.empleadoArray.length + 1;
      this.empleadoArray.push(this.selectedEmpleado);
    }
    this.selectedEmpleado = new Empleados();
  }

  delete(){
    if (confirm('¿¿Estas seguro??')){
      this.empleadoArray = this.empleadoArray.filter(x => x != this.selectedEmpleado)
      this.selectedEmpleado = new Empleados();
    }
  }
}
