import { Empleados } from './empleados';

describe('Empleados', () => {
  it('should create an instance', () => {
    expect(new Empleados()).toBeTruthy();
  });
});
