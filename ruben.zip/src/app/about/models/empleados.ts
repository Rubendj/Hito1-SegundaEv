export class Empleados {
    id: number = 0;
    nombre: string;
    ciudad: string;
}
